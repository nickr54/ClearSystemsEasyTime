This installer installs an unlocked version of EasyTime 2.19 to an existing EasyTime 2.19 install - it is NOT a replacement installer for EasyTime.

The program file "EasyTime219NPL.exe" is added to the EasyTime 2.19 installation folder - usually c:\Program Files (x86)\EayTime219".
The existing key protected EasyTime program is not replaced.
Instead the installer creates additional Desktop and Start Menu shortcuts - use these instead of the originals.
This version will use all existing settings and data.
N.B. Any scripts, bat files etc referencing "EasyTime.exe" must be changed to reference "EasyTime219NPL.exe".
The Uninstaller for just this version is called unist.exe and the Start Menu Folder item is called simple "Uninstall".