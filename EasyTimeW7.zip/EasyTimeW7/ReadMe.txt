Download these files to a new folder "com0com" in the Easy Time installation folder:
e.g. C:\Program Files\EasyTime219\com0com.

Install com0com to the default location of c:\program files\com0com - this should also install the default pair of CNCA0 - CNCB0.

Install hub4com to a new folder named "hub4com" in com0com.

Copy the two EasyTime files to the install directory for com0com.

For fuller details please see the document: Windows7Comms.pdf