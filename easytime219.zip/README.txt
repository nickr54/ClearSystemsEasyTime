This is the install disk for : EasyTime.
Insert the installation disk into your appropriate drive and run the setup program from the Start Menu / Run.
Follow the on-screen prompts until disk set-up is complete.


****** IMPORTANT INFORMATION ******

EasyTime should be installed on the PC to which the EasyTime Card Reader is to be connected.  If you are uncertain about the installation of EasyTime on your PC then please contact us before proceeding.  Please take a backup of any important data on your computer before you start installing this product.

******************************************************************************************
PLEASE NOTE - for installation of EasyTime with the EasyTime V2.0 USB Reader please see the separate document in the EasyTime Reader v2.0 USB folder on the install CD.
******************************************************************************************

+++++++++++++++++++++++++++++WINDOWS+VISTA+AND+WINDOWS+7+++++++++++++++++++++++++++++++++++++++++
Windows Vista and Windows 7 - on installation you should choose to locate the
EasyTime Data and Reporting folders as new folders in an allowed location such as "My Documents"
rather than allowing EasyTime to choose its default - otherwise Windows may choose to "hide" the
EasyTime Data and Reporting folders in a Virtual Store folder in Application Data for your login.
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

You will not be able to run the software until you have registered and obtained a Product Activation Key Code.  When prompted with a Product Lock Code and request for a Product Activation Key, please register your software with Clear Systems Ltd using the "Online Registration" button or contact us by email or phone - see the end of this file.

The Card Reader or Controller (for multiple readers) should be *exclusively* connected to one of COM1, COM2, COM3 or COM4.
Please be aware that devices such as Internal Modems or "Win-modems" by default may use COM3 or COM4 to operate.
Also note that a device attached to COM3 may conflict with a device attached to COM1 and similarly a device attached
to COM4 may conflict with COM2.  This is due to standard PC hardware design and is not an application flaw.
Failure to correctly install the Card Reader on an unused COM port may result in an "interrupt clash" with other hardware on the system, which will likely result in both devices failing to operate.  Please ensure the card reader is connected to an unused COM port or physically remove any potentially conflicting device(s) before connecting the Card Reader and configuring the software.

The Bi-Directional Card Reader should be located horizontally so that swipes follow normal In/Out traffic.  N.B. a forward swipe registers IN clockings and a backward swipe registers OUT clockings. N.B. this does not apply to the Display Reader where pressing the In/Out buttons sets the clocking type until the next time a button is pressed.

On startup you will be asked for :-
A username and password. Enter "admin" and "admin" respectively (lowercase without the quotes).

Select the correct Communications Port with the Options->Port Menu. Then select the Reader Device (DS Low Power Mag Reader for a single RS232 reader OR DS485 Network for multiple readers).
with the Options->Device Menu. Once this is done the Reader's LED should be lit.

To verify the reader is correctly connected unplug and then plug it back into the selected Communications Port
- a message "DS-LPR Magstripe device powered up" should be displayed in the EasyTime Log window.

To verify that badges/cards are read by the reader, check the "View Data Rx" box and swipe a card.
As the card is swiped the LED shuold go out. If the card is not valid a long beep should sound at the reader and a message
"Door 002 Received: ;SOME_NUMBER?" should be displayed in the Log window.

To proceed with correct operation: un-check the "View Data Rx" box and allocated some cards to cardholders using
"Configure Cardholders". Please refer to the on-line help for further information - this is viewed with a Web Browser.


****** NOTES FOR UPGRADERS ******

Before installing the latest version, please ensure you take a copy / backup of your existing database and log files. N.B. to use EasyTime Version 1.nn cards please check the "Use simple 8 digit Card No Format" box in Options, Additional Features.


****** VIEW / CREATE REPORTS ******
****** ON ANOTHER PC ******

1. The EasyTime and the client PC need to be on the same network and the client needs access to the EasyTime's install directory.
2. On the client PC use Network Neighborhood to browse to the EasyTime directory on the EasyTime PC (the default for this is
 \\HOST_PC_NAME\INSTALL_DRIVE_NAME\Program Files\EasyTime VERSION_NO)
3. Right Click on Reporting.exe and, holding the mouse button down, drag it's icon to your windows desktop.  Release the mouse button and click on "Create Shortcut(s) Here".
4. Close the Network Neighborhood window.
5. There should now be a shortcut to Reporting on your desktop.
6. Double-click on the new shortcut to run the reporting program - username and password may be required as above.
7. Click on "Options, Additional Features" to check the Database Path correctly points to the EasyTime directory on the EasyTime PC - it should be set correctly by default.
8. You can now view reports, they are created in both HTML and CSV formats. These are viewable by a Web Browser or Excel.
Remember to check the "Auto Display Reports" box to view reports as they are created.
Note that by default, the report files are created in the EasyTime Database\Reports directory on the EasyTime PC
- they have fixed file names with new reports over-writing old ones.
To create separate copies use "Save As" or, for networked reporting choose a new report directory in the Reporting Options menu.

Clear Systems Ltd can be contacted on support@ClearSystems.co.uk or 0845 643 2440.